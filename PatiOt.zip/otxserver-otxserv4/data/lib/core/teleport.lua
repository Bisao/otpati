function Teleport.isTeleport(self)
	return true
end
