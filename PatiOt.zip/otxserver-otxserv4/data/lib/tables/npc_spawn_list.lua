mapNpcs = {
	-- [1] = {name = "UzonE", pos = {x=32659,y=31913,z=0}},
	-- [2] = {name = "Gewen", pos = {x=32588,y=31942,z=0}},
}
