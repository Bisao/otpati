function canJoin()
	return true
end

function onSpeak()
	return false
end
